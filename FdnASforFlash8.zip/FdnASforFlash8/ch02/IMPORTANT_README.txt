#######################
IMPORTANT - PLEASE READ
#######################

This folder contains only FOUR files (in addition to this one), as follows:

futuremedia.xml
index.html
index.swf
main.swf

THIS IS CORRECT. Although page 44 of "Foundation ActionScript for Flash 8" refers to a total of SIX files, this relates to an earlier version of the Futuremedia website. This oversight will be corrected in future printings of the book. The authors apologize for any confusion.